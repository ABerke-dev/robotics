import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster, StaticTransformBroadcaster
import tf_transformations
import math


class DummyArm(Node):
    def __init__(self):
        super().__init__('dummy_arm')
        self.broadcaster = TransformBroadcaster(self)
        self.static_broadcaster = StaticTransformBroadcaster(self)
        self._publish_static_base()
        self.t = 0.0
        self.dt = 0.05
        self.speed_1 = 0.3
        self.speed_2 = 0.5
        self.speed_3 = 0.7
        self.limit_1 = math.pi / 4
        self.limit_2 = math.pi / 6
        self.limit_3 = math.pi / 3
        self.timer = self.create_timer(self.dt, self.broadcast_transforms)

    def _publish_static_base(self):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'map'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = 0.0
        t.transform.translation.y = 0.0
        t.transform.translation.z = 0.0
        q = tf_transformations.quaternion_from_euler(0.0, 0.0, 0.0)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        self.static_broadcaster.sendTransform(t)

    def make_transform(self, parent, child, x, y, z, roll, pitch, yaw):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = parent
        t.child_frame_id = child
        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = z
        q = tf_transformations.quaternion_from_euler(roll, pitch, yaw)
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        return t

    def broadcast_transforms(self):
        angle_1 = self.limit_1 * math.sin(self.speed_1 * self.t)
        angle_2 = self.limit_2 * math.sin(self.speed_2 * self.t)
        angle_3 = self.limit_3 * math.sin(self.speed_3 * self.t)
        transforms = []
        transforms.append(self.make_transform('base_link', 'joint_1', 0.0, 0.0, 0.3, 0.0, 0.0, angle_1))
        transforms.append(self.make_transform('joint_1', 'joint_2', 0.4, 0.0, 0.0, 0.0, 0.0, angle_2))
        transforms.append(self.make_transform('joint_2', 'joint_3', 0.3, 0.0, 0.0, 0.0, 0.0, angle_3))
        transforms.append(self.make_transform('joint_3', 'end_effector', 0.2, 0.0, 0.0, 0.0, 0.0, 0.0))
        self.broadcaster.sendTransform(transforms)
        self.t += self.dt


def main():
    rclpy.init()
    node = DummyArm()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
